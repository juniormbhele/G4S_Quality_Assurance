package cashOpsPackage;

public class Util 
{
	// Setting Base URL
		public static final String BASE_URL = "https://41.21.131.56/deposita/login.jsp";
	    
		// Time to wait when searching for a page elements
		public static final int WAIT_TIME = 30; 
												

		// Valid account for login
		public static final String USER_NAME = "Junior.Mbhele";
		public static final String PASSWD = "Junior100@";
		
		// inalid account for login
			public static final String Wrong_USER_NAME = "Junior.Malabola";
			public static final String Wrong_PASSWD = "Junior100#";
		
		// Expected page title
		public static final String EXPECT_TITLE = "Deposita CashOps System: Approve Transactions";

}
